import type { Event } from '@agentigram/protocol';
import { beforeEach, describe, expect, it } from 'vitest';
import { REPEAT_WINDOW_MS, SpeechNarrator, WRITE_COOLDOWN_MS } from './speech-narration.js';

let seq = 0;
beforeEach(() => {
  seq = 0;
});

/** `sessionId: null` is the person at the keyboard, which the watcher also reports. */
function write(path: string, sessionId: string | null = 'backend'): Event {
  seq += 1;
  return {
    id: `event-${seq}`,
    seq,
    roomId: 'hackathon',
    ts: new Date().toISOString(),
    actor: {
      engineerId: 'eng-backend',
      ...(sessionId ? { sessionId } : {}),
      kind: sessionId ? 'agent' : 'human',
    },
    source: 'hook',
    payload: { type: 'FILE_WRITE', path, worktree: '/repo' },
  } as Event;
}

describe('narrating what an agent is working on', () => {
  it('says the first file at once and then stays quiet through the burst', () => {
    const narrator = new SpeechNarrator();
    const first = narrator.line(write('src/types/user.ts'), 0);
    expect(first).toMatchObject({ speaker: 'backend', priority: 0 });
    expect(first?.text).toMatch(/^\S+ user\.ts\.$/);

    // A refactor saves far faster than a voice reads; the rest of the burst is silent.
    expect(narrator.line(write('src/checkout.ts'), 1_000)).toBeUndefined();
    expect(narrator.line(write('src/cart.ts'), 2_000)).toBeUndefined();
    expect(narrator.line(write('src/orders.ts'), 3_000)).toBeUndefined();
  });

  it('accounts for everything saved while it was quiet', () => {
    const narrator = new SpeechNarrator();
    narrator.line(write('src/types/user.ts'), 0);
    narrator.line(write('src/checkout.ts'), 1_000);
    narrator.line(write('src/cart.ts'), 2_000);
    narrator.line(write('src/orders.ts'), 3_000);

    // Two names and a count, the way a person reports a batch of edits.
    expect(narrator.line(write('src/refunds.ts'), WRITE_COOLDOWN_MS)?.text).toMatch(
      /^\S+ checkout\.ts, cart\.ts and two other files\.$/,
    );
  });

  it('names two files without a count', () => {
    const narrator = new SpeechNarrator();
    narrator.line(write('src/a.ts'), 0);
    narrator.line(write('src/b.ts'), 1_000);
    expect(narrator.line(write('src/c.ts'), WRITE_COOLDOWN_MS)?.text).toMatch(
      /b\.ts and c\.ts\.$/,
    );
  });

  it('counts one other file in the singular', () => {
    const narrator = new SpeechNarrator();
    narrator.line(write('src/a.ts'), 0);
    narrator.line(write('src/b.ts'), 1_000);
    narrator.line(write('src/c.ts'), 1_500);
    expect(narrator.line(write('src/d.ts'), WRITE_COOLDOWN_MS)?.text).toMatch(
      /and one other file\.$/,
    );
  });

  it('gives each agent its own turn to speak', () => {
    const narrator = new SpeechNarrator();
    expect(narrator.line(write('src/a.ts', 'backend'), 0)).toBeDefined();
    // One agent's burst must not silence another's first word.
    expect(narrator.line(write('src/b.ts', 'payments'), 10)).toBeDefined();
    expect(narrator.line(write('src/c.ts', 'backend'), 20)).toBeUndefined();
  });

  it('does not read the engineer their own edits back', () => {
    const narrator = new SpeechNarrator();
    expect(narrator.line(write('README.md', null), 0)).toBeUndefined();
  });

  it('reports one save once, however many sources notice it', () => {
    // A hook and the watcher flush can both see a single write.
    const narrator = new SpeechNarrator();
    narrator.line(write('src/a.ts'), 0);
    narrator.line(write('src/types/user.ts'), 1_000);
    narrator.line(write('src/types/user.ts'), 1_100);
    expect(narrator.line(write('src/b.ts'), WRITE_COOLDOWN_MS)?.text).toMatch(
      /^\S+ user\.ts and b\.ts\.$/,
    );
  });

  it('varies the wording without becoming unpredictable', () => {
    // Indexed by the event's own sequence number: reproducible, not random.
    const verb = (at: number) => {
      seq = at - 1;
      return new SpeechNarrator().line(write('src/a.ts'), 0)?.text.split(' ')[0];
    };
    expect(verb(7)).toBe(verb(7));
    expect(new Set([verb(1), verb(2), verb(3), verb(4)]).size).toBeGreaterThan(1);
  });

  it('stays silent for anything that is not a write', () => {
    const narrator = new SpeechNarrator();
    const read = { ...write('src/a.ts'), payload: { type: 'FILE_READ', path: 'src/a.ts' } } as Event;
    expect(narrator.line(read, 0)).toBeUndefined();
  });
});

/** Presence carries the session it is about, which is not the session that reported it. */
function presence(type: 'SESSION_STARTED' | 'SESSION_ENDED', sessionId: string): Event {
  seq += 1;
  return {
    ...write('src/a.ts', sessionId),
    payload:
      type === 'SESSION_STARTED'
        ? { type, sessionId, host: 'codex', model: 'gpt', branch: 'main' }
        : { type, sessionId },
  } as Event;
}

describe('announcing who is in the room', () => {
  it('says an arrival once, however many events report it', () => {
    const narrator = new SpeechNarrator();
    // The daemon announces on WELCOME and the host's own hook fires a moment later.
    expect(narrator.line(presence('SESSION_STARTED', 'bob'), 0)?.text).toBe('Bob joined the room.');
    expect(narrator.line(presence('SESSION_STARTED', 'bob'), 400)).toBeUndefined();
    // Its own farewell, then the authority noticing the socket close: one departure.
    expect(narrator.line(presence('SESSION_ENDED', 'bob'), 500)?.text).toBe('Bob left the room.');
    expect(narrator.line(presence('SESSION_ENDED', 'bob'), 900)).toBeUndefined();
  });

  it('announces an agent the authority already believed was here', () => {
    // The case that used to be silent: restarting the authority restores a roster that still
    // lists Bob, then Bob's daemon re-announces itself on reconnect. The room has not heard it.
    const narrator = new SpeechNarrator();
    expect(narrator.line(presence('SESSION_STARTED', 'bob'), 0)).toBeDefined();
  });

  it('does not repeat an arrival later in the same daemon run', () => {
    const narrator = new SpeechNarrator();
    narrator.line(presence('SESSION_STARTED', 'bob'), 0);
    expect(narrator.line(presence('SESSION_STARTED', 'bob'), REPEAT_WINDOW_MS)).toBeUndefined();
  });

  it('keeps one agent from muffling another', () => {
    const narrator = new SpeechNarrator();
    expect(narrator.line(presence('SESSION_STARTED', 'bob'), 0)).toBeDefined();
    expect(narrator.line(presence('SESSION_STARTED', 'payments'), 10)).toBeDefined();
  });

  it('deduplicates identical spoken lines within the repeat window', () => {
    const narrator = new SpeechNarrator();
    const msg: Event = {
      id: 'event-100',
      seq: 100,
      roomId: 'hackathon',
      ts: new Date().toISOString(),
      actor: { engineerId: 'system', kind: 'system' },
      source: 'system',
      payload: {
        type: 'MESSAGE',
        to: 'all',
        text: 'The debate is settled.',
      },
    };
    expect(narrator.line(msg, 0)).toBeDefined();
    expect(narrator.line(msg, 1_000)).toBeUndefined();
    expect(narrator.line(msg, REPEAT_WINDOW_MS + 1)).toBeDefined();
  });

  it('deduplicates identical spoken lines even when the attributed speaker changes', () => {
    const narrator = new SpeechNarrator();
    const message = (seq: number, sessionId?: string): Event => ({
      id: `event-${seq}`,
      seq,
      roomId: 'hackathon',
      ts: new Date().toISOString(),
      actor: sessionId
        ? { engineerId: 'system', sessionId, kind: 'agent' }
        : { engineerId: 'system', kind: 'system' },
      source: 'system',
      payload: {
        type: 'MESSAGE',
        to: 'all',
        text: 'Orchestrator: backend owns user.ts.',
      },
    });

    expect(narrator.line(message(200), 0)).toBeDefined();
    expect(narrator.line(message(201, 'backend'), 1_000)).toBeUndefined();
  });

  it('introduces the orchestrator plan only once', () => {
    const narrator = new SpeechNarrator();
    const plan = (seq: number, text: string): Event => ({
      id: `event-${seq}`,
      seq,
      roomId: 'hackathon',
      ts: new Date().toISOString(),
      actor: { engineerId: 'system', kind: 'system' },
      source: 'system',
      payload: { type: 'MESSAGE', to: 'all', text },
    });

    expect(narrator.line(plan(300, 'Orchestrator: backend owns user.ts.'), 0)).toBeDefined();
    expect(
      narrator.line(plan(301, 'Orchestrator: payments owns checkout.ts.'), REPEAT_WINDOW_MS + 1),
    ).toBeUndefined();
  });
});

